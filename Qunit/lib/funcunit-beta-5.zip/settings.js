FuncUnit = {
	// the list of browsers that selenium runs tests on
	browsers: null, //["*firefox", "*iexplore"],
	
	// the root for all paths in the tests, defaults to filesystem
	jmvcRoot: null, // "http://localhost:8000/",
	
	// the number of milliseconds between Selenium commands, "slow" is 500 ms
	speed: null, //"slow"
}